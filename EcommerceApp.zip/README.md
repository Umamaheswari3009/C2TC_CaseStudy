EcommerceApp - Core Java Console Application (OOP)
-------------------------------------------------
How to compile:
Navigate to src/main/java and run:
  javac main/App.java model/*.java service/*.java util/*.java

How to run:
  java main.App

Project structure:
  src/main/java/model    -> entity classes
  src/main/java/service  -> service layer
  src/main/java/util     -> utilities
  src/main/java/main     -> driver App.java
